__all__ = ["StationDB",]


class StationDB(object):
    """ Read a station DB in csv format, and provide station information
    """
    def __init__(self, fname):
        """ Constructor

            fname:
                csv station file
        """
        import csv
        self.data={}
        self.header = None
        with open(fname,"r") as f:
            dialect = csv.Sniffer().sniff(f.read(2048),delimiters=",")
            f.seek(0)
            r = csv.reader(f)

            for line in r:
                if not self.header:
                    columns = line
                    self.header = columns
                    self.ndx_station_id = columns.index("Id")
                    self.ndx_name = columns.index("Name")
                    self.ndx_alias = columns.index("alias_id2")
                else:
                    data = line
                    id = str(data[self.ndx_station_id])
                    if len(data) == len(self.header):
                        self.data[id] = data
                    else:
                        raise ValueError("Station with id %s has incorrect number of columns compared to header (%s vs %s)" % (id,len(data),len(self.header)))


    def alias(self, station_id):
        """ Get an alias of a station with ID
            station_id:
                station name
        """
        alias = None
        if station_id in self.data.keys():
            alias = self.data[station_id][self.ndx_alias]
   
        return alias

    def name(self, station_id):
        """ Get a long name of a station with an ID

            Parameters
            ----------
            station_id:
                station name

            Returns
            -------
            str
                a long name of a station
        """
        long_name = None
        if station_id in self.data.keys():
            long_name = self.data[station_id][self.ndx_name]
        return long_name

    def station_ids_from_alias(self, alias):
        ids = [x for x in self.data.keys() if self.data[x][self.ndx_alias] == alias]
        return ids
        
    def station_attribute(self,station_id,attrname):
        if not station_id in self.data.keys():
            raise ValueError("Station ID not on station list")
        try:
            ndx = self.header.index(attrname)
            return self.data[station_id][ndx]
        except:
            print "Dumping column headers: "
            import string
            print self.header #string.join(self.header,",")
            raise ValueError("Unable to retrieve attribute %s for station_id %s" % (attrname,station_id))
            
        
        
        